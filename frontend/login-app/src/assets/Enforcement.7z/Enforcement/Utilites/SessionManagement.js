const crypto = require('crypto');
const Session = require('./../Models/Session');
const { serverLogger } = require('./ServerLogging');

let sessions = [];
console.log("ytyhdggjgj", sessions)

async function getAllSession() {
    return sessions;
}

async function generateSessionId() {
    return crypto.randomBytes(16).toString('hex'); // Generates a 32-character hexadecimal string
}

async function startSession(featureID,userId,licenseId) {
    try {
        console.log("dsf",userId)
        const sessionId = await generateSessionId();
        const timestamp = new Date();
        const newSession = new Session(sessionId, featureID,userId,licenseId, timestamp);
        sessions.push(newSession);
        console.log("session",sessions)
        serverLogger.info(`Session started: ${sessionId} for features: ${featureID} at ${timestamp}`);
        return sessionId;
    } catch (error) { 
        console.error(`Error starting session: ${error.message}`);
    }
}

async function closeFeatureInSession(sessionId, featureID) {
    console.log("ytyhdggjgj",sessions)
    console.log("Closing feature in session:", sessionId, "Feature ID:", featureID);
    for (let i = 0; i < sessions.length; i++) {
        console.log("Checking session:", sessions[i]);
        if (sessions[i].sessionId === sessionId) {
            if (sessions[i].featureID === featureID) {
                sessions.splice(i, 1);
                console.log(`Session ${sessionId} closed and removed for feature ${featureID}`);
                console.log("fhfdughdfhg",sessions)
                return;
            } else {
                console.error(`Feature ID ${featureID} not found in session ${sessionId}.`);
            }
        }
    }
    console.error(`Session ID ${sessionId} not found.`);
}

module.exports = {
    startSession,
    closeFeatureInSession,
    getAllSession
};