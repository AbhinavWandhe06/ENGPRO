const crypto = require('crypto');
const fs = require('fs');
const path = require('path');


// Load config from config.json
const configPath = path.join(__dirname, '../config.json');
const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));

const FP_SECRET_KEY = config.FP_SECRET_KEY;
const FP_IV = config.FP_IV;
const L_SECRET_KEY = config.L_SECRET_KEY;
const L_IV = config.L_IV;

// Encrypt function using AES-256-CBC
async function encrypt(text) {
  const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(FP_SECRET_KEY), Buffer.from(FP_IV));
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  return encrypted;
}

// Encrypt function using AES-256-CBC
async function LicenseEncrypt(data) {
  const text = Buffer.from(data, 'utf8');
  const iv = Buffer.from(L_IV, 'base64');
  const key = Buffer.from(L_SECRET_KEY, 'utf8');

  // Encrypt the data using AES-256-CBC
  const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
  let encrypted = cipher.update(text, 'utf8', 'base64');
  encrypted += cipher.final('base64');

  return encrypted;
}

// Decrypt function using AES-256-CBC
async function decrypt(encryptedText) {
  const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(L_SECRET_KEY), Buffer.from(L_IV, 'Base64'));
  let decrypted = decipher.update(encryptedText, 'hex', 'utf8');
  decrypted += decipher.final('utf8');
  return decrypted;
}

// Export the encrypt function
module.exports = {
  encrypt,
  decrypt,
  LicenseEncrypt
};