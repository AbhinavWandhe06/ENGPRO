const si = require('systeminformation');
const crypto = require('crypto');
const { encrypt, decrypt, LicenseEncrypt } = require('./EncryptDecryptUtil');
const fs = require('fs');
const path = require('path');
const os = require('os');
const xmlbuilder = require('xmlbuilder');
const { serverLogger } = require('./ServerLogging');
const { licenseParser, fingerprintParser, entitlementParser, getProduct, getFeature, getLicenseId } = require('./XmlParser');
const config = require("../config.json")
const { xml2js, js2xml } = require('xml-js');

let cachedDiskId = null;
async function getDiskId() {
  if (!cachedDiskId) {
    const disks = await si.diskLayout();
    cachedDiskId = disks.map(disk => disk.serialNum).join(',');
  }
  return cachedDiskId;
}

async function getFingerprint() {
  try {
    console.time("getFingerprint");

    // Parallelize asynchronous calls
    const [cpuModel, OSType, diskId, UUID, bios] = await Promise.all([
      os.cpus()[0].model,
      os.type(),
      getDiskId(),
      si.uuid(),
      si.bios()
    ]);

    const uuid = UUID.os;
    const biosId = bios.serial;

    // Create fingerprint
    const fingerprint = `${cpuModel}-${OSType}-${biosId}-${diskId}-${uuid}`;

    // Hashing using SHA256
    const hash = crypto.createHash('sha256').update(fingerprint).digest('hex');

    // Encrypt the hash (assuming encrypt is an async function)
    const encryptedFingerprint = await encrypt(hash);

    console.timeEnd("getFingerprint");
    return encryptedFingerprint;
  } catch (error) {
    console.error(`Error generating fingerprint: ${error.message}`);
    throw error;
  }
}

// Function to convert fingerprint to XML and save to a file
async function saveFingerprintToXML(fingerprint) {
  if (!fingerprint) {
    console.error('Error: fingerprint is undefined or null');
    return;
  }

  try {
    const timestamp = new Date().toISOString();
    const fingerprintObj = {
      _declaration: { _attributes: { version: '1.0', encoding: 'utf-8' } },
      fingerprint: {
        _attributes: { timestamp: timestamp },
        host_fp: { _text: fingerprint }
      }
    };
    const xmlContent = js2xml(fingerprintObj, { compact: true, spaces: 4 });
    return xmlContent;

  } catch (error) {
    console.error('Error saving fingerprint to XML:', error);
  }
}

//fingerprint for update flow
async function GenerateUpdatedLicenseXML(fingerprint, licenseId) {
  try {
    let licenseDir;
    if (config.standalone_Installation === "false") {
      licenseDir = path.join(__dirname, './../License/Centralized');
    }
    else {
      licenseDir = path.join(__dirname, './../License/Standalone');
    }

    // Get all files in the directory 
    const files = fs.readdirSync(licenseDir).filter(file => file.startsWith(`${licenseId}_`) && file.endsWith('.lic'));

    // Find the file with the highest suffix number 
    const highestFile = files.reduce((maxFile, file) => {
      const suffix = parseInt(file.split('_')[1].split('.')[0], 10);
      const maxSuffix = parseInt(maxFile.split('_')[1].split('.')[0], 10);
      return suffix > maxSuffix ? file : maxFile;
    }, files[0]);

    const licenseFilePath = path.join(licenseDir, highestFile);
    const licenseContent = fs.readFileSync(licenseFilePath, 'utf8');
    const timestamp = new Date().toISOString();
    const license = await licenseParser(licenseContent)
    const id = license.id
    const userId =license.userId
    const content = license.license
    const version = license.version
    const vendor_code = license.vendor_code
    const transfered =license.transfered
    serverLogger.info("LicensePRINT.........", license.license);

    // Prepare the JSON structure for conversion 
    const jsonStructure = {
      updatedLicense: {
        license: {
          license_info: {
            _attributes: { id: id, userId: userId, vendor_code: vendor_code, transfered: transfered, version: version },
            lic: content
          },
        },
        fingerprint: {
          _attributes: { timestamp: timestamp },
          host_fp: fingerprint
        }
      }
    };

    // Convert JSON to XML 
    const xmlContent = js2xml(jsonStructure, { compact: true, ignoreComment: true, spaces: 4 });

    console.log("dfsdufskgufukd", xmlContent);

    return xmlContent; // Return the generated XML content
  } catch (error) {
    console.error('Error generating updated license XML:', error);
    return error.message; // Return the error message
  }
}

module.exports = {
  getFingerprint,
  saveFingerprintToXML,
  GenerateUpdatedLicenseXML,
};
