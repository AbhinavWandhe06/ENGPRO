const {generateLicenseXml}=require("./LicenseUtil")
const {
  LicenseDirectory,
} = require("./LicenseUtil");
const {
  getFeature,
  getProduct,
  getEntitlement,
  getLicenseId,
} = require("./XmlParser");
const fs = require("fs");
const path = require("path");
const config = require("./../config.json")
const { LicenseModifier, LicenseObjModifier } = require("./LicenseUtil")
const {db,ensureTableExists,storeUserLicenseMapping,updateFeatureInDb} = require('./Database');

async function ExecutionCount(feature, licenseId) {
  console.log("Before modification:", feature);
  const issuedCount = feature.issuedCount;
  let consumedCount = feature.consumedCount;
  let availableCount = feature.availableCount;

  if (consumedCount === issuedCount && availableCount === 0) {
    return false;
  } else {
    consumedCount += 1;
    availableCount = issuedCount - consumedCount;
    feature.consumedCount = consumedCount;
    feature.availableCount = availableCount;
    console.log("After modification:", feature);

    // Update the feature in the database
    const updateResult = await updateFeatureInDb(feature, licenseId);
    console.log("Update result:", updateResult);

    // Optionally modify the feature in the license object (if required)
    // await LicenseObjModifier(feature, license);

    return true;
  }
}



async function Trial(feature, licenseId) {
  const currentDate = new Date();

  // If startDate is not set, initialize it and set endDate to noOFDays days from startDate
  if (!feature.startDate) {
    feature.startDate = currentDate.toISOString();
    const endDate = new Date(currentDate);
    endDate.setDate(endDate.getDate() + feature.noOfDays);
    console.log("gfdgd",feature.startDate)
    feature.endDate = endDate.toISOString();
    // console.log("Start Date set to:", feature.startDate);
    // console.log("End Date set to:", feature.endDate);
    // Update the feature in the database 
    await updateFeatureInDb(feature, licenseId);
  }

  const currentDateObj = new Date();
  const endDateObj = new Date(feature.endDate);

  // console.log("currentDateObj", currentDateObj.toISOString());
  // console.log("endDateObj", endDateObj.toISOString());

  // Check if the current date is less than or equal to the end date
  if (currentDateObj <= endDateObj) {
    // feature.endDate = endDateObj.toISOString();
    // console.log("after", feature);
    // await LicenseObjModifier(feature, licenseId);
    console.log("Feature is still valid. End Date is:", endDateObj.toISOString());
    return true;
  } else {
    return false;
  }
}

async function Perpetual(feature) {
  if (feature.enable == true) {
    return true;
  } else {
    feature.enable == false
    return false;
  }
}

async function Subscription(feature, licenseId) {
  if (feature.enable == true) {
    return true;
  } else {
    return false;
  }
}

// async function Subscription(feature, licenseId) {
//   const currentDate = new Date();
//   const currentTimeEpoch = currentDate.getTime();
  
//   // Get current time in epoch  
//   const endDate = new Date(feature.endDate);
//   const endTimeEpoch = endDate.getTime();
  
//   // Get end time in epoch  
//   if (currentTimeEpoch <= endTimeEpoch && feature.enable) {
//     return true;
//   } else {
//     feature.enable = false;
    
//     // If subscription has expired, disable the feature    
//     await LicenseModifier(feature, licenseId);
//     // Update the feature state    
//     return false;
//   }
// }

module.exports = {
  ExecutionCount,
  Trial,
  Perpetual,
  Subscription,
};
