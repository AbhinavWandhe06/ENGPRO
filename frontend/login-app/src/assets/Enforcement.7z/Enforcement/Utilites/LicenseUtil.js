const { encrypt, decrypt, LicenseEncrypt } = require('./EncryptDecryptUtil');
const fs = require('fs');
const path = require('path');
const { xml2js, js2xml } = require('xml-js');
const { serverLogger } = require('./ServerLogging');
const { licenseParser, fingerprintParser, entitlementParser, getProduct, getFeature, getLicenseId } = require('./XmlParser');
const config = require("./../config.json");
const { getFingerprint, saveFingerprintToXML } = require('./FingerprintUtil');
const { db, ensureTableExists, storeUserLicenseMapping, addEntitlementWithProductsAndFeatures } = require('./Database');

let allLicenses = []; // Global variable to store all licenses

async function getAllLicense() {
    return allLicenses;
}

async function setAllLicenses(allLicenses) {
    allLicenses = allLicenses;
    console.log("Licenses updated successfully.");
}

// Function to validate and install the License file
async function isLicenseValid(licenseContent) {
    try {
        console.time("generatedFingerprint");
        const generatedFingerprint = await getFingerprint();
        console.timeEnd("generatedFingerprint");

        const modelParsed = await licenseParser(licenseContent);
        const licensefileContent = modelParsed.license;
        const licenseId = modelParsed.id;
        const userId = modelParsed.userId;
        let licenseVersion = modelParsed.version;
        console.log("Current license version:", licenseVersion);

        const Base64LicenseInfo = Buffer.from(licensefileContent, 'base64');
        const decryptedLicenseInfo = await decrypt(Base64LicenseInfo.toString('hex'));
        const licenseFingerprint = await fingerprintParser(decryptedLicenseInfo);

        if (generatedFingerprint === licenseFingerprint) {

            let licenseDir;
            if (config.standalone_Installation === "true") {
                licenseDir = path.join(__dirname, `./../License/Standalone/`)
            } else {
                licenseDir = path.join(__dirname, `./../License/Centralized/`);
            }

            if (!fs.existsSync(licenseDir)) {
                fs.mkdirSync(licenseDir, { recursive: true });
            }

            // Determine the next version number and filename 
            const existingFiles = fs.readdirSync(licenseDir).filter(file => file.startsWith(licenseId));
            let nextVersion = 0;
            if (existingFiles.length > 0) {
                const highestVersionFile = existingFiles.reduce((max, file) => {
                    const parts = file.split('_');
                    const version = parts.length > 1 ? parseInt(parts[1].split('.')[0], 10) : 0;
                    return Math.max(max, version);
                }, 0); nextVersion = highestVersionFile + 1;
            }

            licenseVersion = nextVersion;
            const licenseFilePath = path.join(licenseDir, `${licenseId}_${licenseVersion}.lic`);

            // Create the XML format for the license 
            const licenseXML =
                `<?xml version="1.0" encoding="utf-8"?>
<license>
    <license_info id="${licenseId}" userId="${userId}" vendor_code="" transfered="false" version="${licenseVersion}"> 
        <lic>${modelParsed.license}</lic> 
</license_info>
</license>`;

            if (config.standalone_Installation === "false") {
                if (userId === "") {
                    serverLogger.error(`Error validating license: ${error.message}`);
                    throw error;
                }
                const start = decryptedLicenseInfo.indexOf('<entitlement');
                const end = decryptedLicenseInfo.indexOf('</entitlement>') + '</entitlement>'.length;
                const relevantXmlContent = decryptedLicenseInfo.substring(start, end);

                const EntitlementParser = await entitlementParser(relevantXmlContent);

                // Store the parsed license information in the database
                await extractLicenseInfotoStoreinDb(EntitlementParser, licenseId, userId);
            }
            fs.writeFileSync(licenseFilePath, licenseXML, 'utf8');
            serverLogger.info(`License content written to file: ${licenseFilePath}`);

            return true;
        } else {
            serverLogger.warn('License is not valid.');
            return false;
        }
    } catch (error) {
        serverLogger.error(`Error validating license: ${error.message}`);
        throw error;
    }
}






//fetch all license
async function LicenseDirectory() {
    let licenseDir;

    if (config.standalone_Installation === "true") {
        licenseDir = path.join(__dirname, "./../License/Standalone");
    } else {
        licenseDir = path.join(__dirname, "./../License/Centralized");
    }
    // console.log("licenseDir", licenseDir)
    const files = fs.readdirSync(licenseDir);
    const licenseMap = {};

    // Group files by licenseId and keep track of the highest suffix
    for (const file of files) {
        const [licenseId, suffix] = file.replace('.lic', '').split('_');
        if (!licenseMap[licenseId] || parseInt(suffix) > parseInt(licenseMap[licenseId].suffix)) {
            licenseMap[licenseId] = { file, suffix };
        }
    }
    const allLicenses = [];

    for (const { file } of Object.values(licenseMap)) {
        const filePath = path.join(licenseDir, file);
        const licenseContent = fs.readFileSync(filePath, "utf8");
        const modelParsed = await licenseParser(licenseContent);
        const licenseId = modelParsed.id;
        const userId = modelParsed.userId;
        const licensefileContent = modelParsed.license;

        const Base64LicenseInfo = Buffer.from(licensefileContent, 'base64');
        const decryptedLicenseInfo = await decrypt(Base64LicenseInfo.toString('hex'));
        const start = decryptedLicenseInfo.indexOf('<entitlement');
        const end = decryptedLicenseInfo.indexOf('</entitlement>') + '</entitlement>'.length;
        const relevantXmlContent = decryptedLicenseInfo.substring(start, end);
        // console.log("relevantXmlContent", relevantXmlContent)
        const EntitlementParser = await entitlementParser(relevantXmlContent);
        // console.log("EntitlementParser", EntitlementParser)
        const entitlement = await extractLicenseInfo(EntitlementParser, licenseId, userId);
        // console.log("entitlement", entitlement)
        allLicenses.push(entitlement);
    }

    // console.log("allLicendsdsdses", allLicenses)
    return allLicenses;
};

//store all Licenses
async function LicenseObjectStorage(LicenseId) {
    let licenseDir;

    const currentTime = new Date().getTime();

    if (config.standalone_Installation === "true") {
        licenseDir = path.join(__dirname, "./../License/Standalone");
    } else {
        licenseDir = path.join(__dirname, "./../License/Centralized");
    }
    // console.log("licenseDir", licenseDir)
    const files = fs.readdirSync(licenseDir);
    const matchingFiles = files.filter(file => file.startsWith(LicenseId.substring(0, 18)));

    if (matchingFiles.length === 0) {
        console.error("No matching license files found.");
        return [];
    }

    // Sort matching files to find the one with the highest value after the underscore 
    const selectedFile = matchingFiles.sort((a, b) => {
        const aSuffix = parseInt(a.split('_')[1], 10) || 0;
        const bSuffix = parseInt(b.split('_')[1], 10) || 0;
        return bSuffix - aSuffix;
        // Descending order 
    })[0];

    console.log("selectedFilepath", selectedFile)
    const filePath = path.join(licenseDir, selectedFile);
    const licenseContent = fs.readFileSync(filePath, "utf8");
    const modelParsed = await licenseParser(licenseContent);
    const licenseId = modelParsed.id;
    const userId = modelParsed.userId;
    const licensefileContent = modelParsed.license;

    const Base64LicenseInfo = Buffer.from(licensefileContent, 'base64');
    const decryptedLicenseInfo = await decrypt(Base64LicenseInfo.toString('hex'));
    const start = decryptedLicenseInfo.indexOf('<entitlement');
    const end = decryptedLicenseInfo.indexOf('</entitlement>') + '</entitlement>'.length;
    const relevantXmlContent = decryptedLicenseInfo.substring(start, end);

    const EntitlementParser = await entitlementParser(relevantXmlContent);
    const licenseObj = await extractLicenseInfotoStoreinDb(EntitlementParser, licenseId, userId);
    console.log("licenseObj", licenseObj);

    allLicenses.push({ ...licenseObj, addedTime: currentTime });

    // Clean up old licenses 
    allLicenses = await checkAndRemoveOldLicenses(allLicenses);

    return licenseObj;
};

//use Epoch time later
const checkAndRemoveOldLicenses = async (allLicenses) => {
    const twelveHoursInMillis = 12 * 60 * 60 * 1000;// change to 12 hours later
    const currentTime = new Date().getTime();

    // Filter out licenses that are older than 12 hours
    const validLicenses = allLicenses.filter(license => (currentTime - license.addedTime) <= twelveHoursInMillis);
    return validLicenses;
};


// Function to fetch license information
async function extractLicenseInfo(parsedLicense, licenseId, userId) {
    // console.log("efsesfsf", parsedLicense.entitlementId)

    const entitlement = {
        userId: userId,
        licenseId: licenseId,
        entitlementId: parsedLicense.entitlementId,
        products: parsedLicense.products.map(product => ({
            productId: product.productId,
            productName: product.productName,
            features: product.features.map(feature => ({
                featureId: feature.featureId,
                featureName: feature.featureName,
                enable: feature.enable,
                businessModel: feature.businessModel,
                startDate: feature.startDate,
                issuedCount: feature.issuedCount,
                consumedCount: feature.consumedCount,
                availableCount: feature.availableCount,
                endDate: feature.endDate,
                noOfDays: feature.noOfDays
            }))
        }))
    };

    serverLogger.info("Extracted Entitlement:", JSON.stringify(entitlement, null, 2));
    return entitlement;
}


//generate license xml
async function extractLicenseInfotoStoreinDb(parsedLicense, licenseId, userId) {
    const entitlement = {
        userId: userId,
        licenseId: licenseId,
        entitlementId: parsedLicense.entitlementId,
        products: parsedLicense.products.map(product => ({
            productId: product.productId,
            productName: product.productName,
            features: product.features.map(feature => ({
                featureId: feature.featureId,
                featureName: feature.featureName,
                enable: feature.enable,
                businessModel: feature.businessModel,
                startDate: feature.startDate,
                issuedCount: feature.issuedCount,
                consumedCount: feature.consumedCount,
                availableCount: feature.availableCount,
                endDate: feature.endDate,
                noOfDays: feature.noOfDays
            }))
        }))
    };

    try {
        // Ensure the tables exist before attempting to insert data
        await ensureTableExists();

        // Store the user license mapping
        await storeUserLicenseMapping(entitlement.userId, entitlement.licenseId);

        // Add the entitlement with products and features to the database
        await addEntitlementWithProductsAndFeatures(
            entitlement.userId,
            entitlement.licenseId,
            entitlement.entitlementId,
            entitlement.products
        );

        console.log("License information stored successfully.");
        return entitlement;
    } catch (err) {
        console.error("Error storing license information:", err);
        return entitlement;
    }
}


async function generateLicenseXml(entitlementObj) {
    const declaration = '<?xml version="1.0" encoding="utf-8"?>';
    const fingerprintContent = await getFingerprint()
    const fingerprint = await saveFingerprintToXML(fingerprintContent);
    const fp = fingerprint.startsWith(declaration) ? fingerprint.slice(declaration.length).trim() : fingerprint;

    const entitlementXml = `<encrypted_data>${js2xml(
        {
            entitlement: {
                _attributes: {
                    entitlementId: entitlementObj.entitlementId,
                    timestamp: entitlementObj.timestamp
                },
                productList: {
                    product: entitlementObj.products.map(product => ({
                        _attributes: {
                            productId: product.productId,
                            productName: product.productName,
                            enable: true
                        },
                        featureList: {
                            feature: product.features.map(feature => {
                                const baseAttributes = {
                                    featureId: feature.featureId,
                                    featureName: feature.featureName,
                                    enable: feature.enable ? true : false,
                                    businessModel: feature.businessModel,
                                };

                                const startDate = feature.startDate || new Date().toISOString();

                                switch (feature.businessModel) {
                                    case "Perpetual":
                                        return {
                                            _attributes: {
                                                ...baseAttributes,
                                                startDate: startDate,
                                            }
                                        };
                                    case "Subscription":
                                        const endDate = feature.endDate
                                            ? new Date(feature.endDate).toISOString()
                                            : new Date(new Date().setDate(new Date().getDate() + 1)).toISOString();
                                        return {
                                            _attributes: {
                                                ...baseAttributes,
                                                startDate: startDate,
                                                endDate: endDate
                                            }
                                        };
                                    case "ExecutionCount":
                                        return {
                                            _attributes: {
                                                ...baseAttributes,
                                                startDate: startDate,
                                                issuedCount: feature.issuedCount,
                                                availableCount: feature.availableCount,
                                                consumedCount: feature.consumedCount
                                            }
                                        };
                                    case "Trial":
                                        return {
                                            _attributes: {
                                                ...baseAttributes,
                                                startDate: feature.startDate,
                                                endDate: feature.endDate,
                                                noOfDays: feature.noOfDays
                                            }
                                        };
                                    default:
                                        return { _attributes: baseAttributes };
                                }
                            })
                        }
                    }))
                }
            }
        },
        { compact: true, spaces: 4 }
    )}\n${fp}</encrypted_data>`;
    const EncryptedEntitlement = await LicenseEncrypt(entitlementXml);

    // Wrap encrypted content in a license XML structure  
    const xmlContent = `<?xml version="1.0" encoding="utf-8"?>\n<license>
      <license_info id="${entitlementObj.licenseId}" userId="${entitlementObj.userId}">
        <lic>${EncryptedEntitlement}</lic>
      </license_info>
    </license>`;
    return xmlContent;
};

// Function to modify a license object when features are used
async function LicenseObjModifier(feature, license) {
    const licenseId = license.licenseId;
    let allStoredLicenses = await getAllLicense();
    let licenseToUpdate = allStoredLicenses.find(l => l.licenseId === licenseId);

    if (!licenseToUpdate) {
        console.log("License not found, fetching from storage...");
        licenseToUpdate = await LicenseObjectStorage(licenseId);
        if (licenseToUpdate) {
            allStoredLicenses.push(licenseToUpdate);
        } else {
            console.warn("License ID not found");
            return false;
        }
    }

    // Update the specific feature in the license
    licenseToUpdate.products.forEach((product) => {
        product.features.forEach((feat, index) => {
            if (feat.featureId === feature.featureId) {
                product.features[index] = feature;
            }
        });
    });

    // Remove the old license and add the updated license
    allStoredLicenses = allStoredLicenses.filter(l => l.licenseId !== licenseId);
    allStoredLicenses.push(licenseToUpdate);

    // Save the updated licenses back
    await setAllLicenses(allStoredLicenses);

    return true;
}


module.exports = {
    isLicenseValid,
    LicenseDirectory,
    generateLicenseXml,
    LicenseObjectStorage,
    getAllLicense,
    LicenseObjModifier,
    extractLicenseInfo
}