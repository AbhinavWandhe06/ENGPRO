const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const path = require('path');
const serverLogger = require("./ServerLogging")
const config = require("./../config.json")

if (config.standalone_Installation !== "true") {
  // Database file path
  const dbPath = path.join(__dirname, 'licenses.db');

  // Check if the database file exists
  if (!fs.existsSync(dbPath)) {
    console.log("Database file does not exist. Creating a new database file.");
    fs.writeFileSync(dbPath, '');
  }

  // Create a new SQLite database (or connect to an existing one)
  const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
      console.error('Error opening database:', err.message);
    } else {
      console.log('Connected to the SQLite database.');

      // Check the size of the database file
      if (fs.statSync(dbPath).size === 0) {
        console.log("Database file is empty. Creating the licenses table.");
        createTables()
          .then(() => {
            console.log('Licenses table created.');
          }).catch((err) => {
            console.error(err);
          });
      } else {
        console.log("Database file exists and is not empty.");
      }
    }
  });

  function createTables() {
    return new Promise((resolve, reject) => {
      db.serialize(() => {
        // Create licenses table if not exists 
        db.run(`CREATE TABLE IF NOT EXISTS licenses ( 
        recordId INTEGER PRIMARY KEY AUTOINCREMENT,
        userId TEXT NOT NULL,
        licenseId TEXT NOT NULL,
        UNIQUE(userid, licenseid)
        )`, (err) => {
          if (err) {
            reject('Error creating licenses table: ' + err.message);
          }
        });

        // Create entitlements table if not exists 
        db.run(`CREATE TABLE IF NOT EXISTS entitlements ( 
        recordId INTEGER PRIMARY KEY AUTOINCREMENT,
        licenseMap TEXT NOT NULL,
        entitlementId TEXT NOT NULL,
        FOREIGN KEY (licenseMap) REFERENCES licenses(recordId)
        )`, (err) => {
          if (err) {
            reject('Error creating entitlements table: ' + err.message);
          }
        });

        // Create products table if not exists 
        db.run(`CREATE TABLE IF NOT EXISTS products ( 
        recordId INTEGER PRIMARY KEY AUTOINCREMENT,
        productId TEXT NOT NULL,
        entitlementMap INTEGER NOT NULL,
        productName TEXT NOT NULL,
        FOREIGN KEY (entitlementMap) REFERENCES entitlements(recordId)
        )`, (err) => {
          if (err) {
            reject('Error creating products table: ' + err.message);
          }
        });

        // Create features table if not exists 
        db.run(`CREATE TABLE IF NOT EXISTS features ( 
        recordId INTEGER PRIMARY KEY AUTOINCREMENT,
        featureId TEXT NOT NULL,
        productMap INTEGER NOT NULL,
        featureName TEXT NOT NULL,
        enable BOOLEAN NOT NULL,
        businessModel TEXT NOT NULL,
        startDate TEXT,
        issuedCount INTEGER,
        consumedCount INTEGER,
        availableCount INTEGER,
        endDate TEXT,
        noOfDays INTEGER,
        FOREIGN KEY (productMap) REFERENCES products(recordId)
        )`, (err) => {
          if (err) {
            reject('Error creating features table: ' + err.message);
          }
        });
        resolve('Tables created or already exist.');
      });
    });
  }

  function ensureTableExists() {
    return createTables();
  }

  // Close the database connection when done
  process.on('exit', () => {
    db.close((err) => {
      if (err) {
        console.error('Error closing database:', err.message);
      } else {
        console.log('Database connection closed.');
      }
    });
  });

  // Function to get licenseId by userId 
  const getLicenseIdByUserId = (userId) => {
    return new Promise((resolve, reject) => {

      console.log("Querying for userId:", userId);
      db.get(`SELECT licenseId FROM licenses WHERE userId = ?`, [userId], (err, row) => {
        if (err) {
          console.error(`Error retrieving licenseId: ${err.message}`);
          reject(err);
        } else {
          if (row) {
            console.log("Retrieved licenseId:", row.licenseId);
            resolve(row.licenseId);
          } else {
            console.log("No licenseId found for userId:", userId);
            resolve(null);
          }
        }
      });
    });
  };

  // Function to store userId and licenseId
  const storeUserLicenseMapping = (userId, licenseId) => {
    return new Promise((resolve, reject) => {
      if (!userId || userId.trim() === "") {
        console.log("Empty userId provided, skipping database insertion.");
        resolve(null);
        return;
      }

      // Insert or replace userId and licenseId in the licenses table
      db.run(`INSERT OR REPLACE INTO licenses (userId, licenseId) VALUES (?, ?)`, [userId, licenseId], (err) => {
        if (err) {
          console.error(`Error storing user-license mapping: ${err.message}`);
          reject(err);
        } else {
          resolve(true);
        }
      });
    });
  };


  // Function to add an entitlement with products and features
  const addEntitlementWithProductsAndFeatures = (licenseId, entitlementId, products) => {
    return new Promise((resolve, reject) => {
      if (!licenseId || licenseId.trim() === "") {
        console.log("Empty licenseId provided, skipping database insertion.");
        resolve(null);
        return;
      }

      db.serialize(() => {
        // Insert or update entitlements table
        db.run(`INSERT OR REPLACE INTO entitlements (licenseMap, entitlementId) VALUES ((SELECT recordId FROM licenses WHERE licenseId = ?), ?)`, [licenseId, entitlementId], function (err) {
          if (err) {
            console.error(`Error inserting into entitlements: ${err.message}`);
            reject(err);
          } else {
            const entitlementRowId = this.lastID;
            products.forEach(product => {
              // Check if the product already exists
              db.get(`SELECT recordId FROM products WHERE productId = ? AND entitlementMap = ?`, [product.productId, entitlementRowId], function (err, row) {
                if (err) {
                  console.error(`Error checking products: ${err.message}`);
                  reject(err);
                } else if (row) {
                  const productRowId = row.recordId;
                  product.features.forEach(feature => {
                    // Check if the feature already exists
                    db.get(`SELECT * FROM features WHERE featureId = ? AND productMap = ?`, [feature.featureId, productRowId], function (err, existingFeature) {
                      if (err) {
                        console.error(`Error checking features: ${err.message}`);
                        reject(err);
                      } else if (existingFeature) {
                        console.log(`Feature already exists: ${feature.featureId}`);
                        // Update feature values based on the business model
                        if (existingFeature.availableCount > 0) {
                          feature.availableCount += existingFeature.availableCount;
                        }
                        if (feature.businessModel === 'Subscription' && new Date(feature.endDate) > new Date(existingFeature.endDate)) {
                          existingFeature.endDate = feature.endDate;
                        }
                        updateFeatureIfInvalid(feature, productRowId);
                      } else {
                        db.run(`INSERT INTO features (featureId, productMap, featureName, enable, businessModel, startDate, issuedCount, consumedCount, availableCount, endDate, noOfDays) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [feature.featureId, productRowId, feature.featureName, feature.enable, feature.businessModel, feature.startDate, feature.issuedCount, feature.consumedCount, feature.availableCount, feature.endDate, feature.noOfDays], (err) => {
                          if (err) {
                            console.error(`Error inserting into features: ${err.message}`);
                            reject(err);
                          } else {
                            console.log(`Inserted feature: ${feature.featureId}`);
                          }
                        });
                      }
                    });
                  });
                } else {
                  // Insert new product
                  db.run(`INSERT INTO products (productId, entitlementMap, productName) VALUES (?, ?, ?)`, [product.productId, entitlementRowId, product.productName], function (err) {
                    if (err) {
                      console.error(`Error inserting into products: ${err.message}`);
                      reject(err);
                    } else {
                      const productRowId = this.lastID;
                      console.log(`Inserted new product: ${product.productId}, recordid: ${productRowId}`);
                      product.features.forEach(feature => {
                        db.run(`INSERT INTO features (featureId, productMap, featureName, enable, businessModel, startDate, issuedCount, consumedCount, availableCount, endDate, noOfDays) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [feature.featureId, productRowId, feature.featureName, feature.enable, feature.businessModel, feature.startDate, feature.issuedCount, feature.consumedCount, feature.availableCount, feature.endDate, feature.noOfDays], (err) => {
                          if (err) {
                            console.error(`Error inserting into features: ${err.message}`);
                            reject(err);
                          } else {
                            console.log(`Inserted feature: ${feature.featureId}`);
                          }
                        });
                      });
                    }
                  });
                }
              });
            });
            resolve(true);
          }
        });
      });
    });
  };

  // Function to update feature values if they are not valid or need adjustments
  const updateFeatureIfInvalid = (feature, productRowId) => {
    // Update the feature with new available count and end date if needed
    const updateQuery = `UPDATE features SET featureName = ?, enable = ?, businessModel = ?, startDate = ?, issuedCount = ?, consumedCount = ?, availableCount = ?, endDate = ?, noOfDays = ? WHERE featureId = ? AND productMap = ?`;
    const updateParams = [feature.featureName, feature.enable, feature.businessModel, feature.startDate, feature.issuedCount, feature.consumedCount, feature.availableCount, feature.endDate, feature.noOfDays, feature.featureId, productRowId];

    db.run(updateQuery, updateParams, function (err) {
      if (err) {
        console.error(`Error updating feature in database: ${err.message}`);
      } else {
        console.log(`Successfully updated feature: ${feature.featureId}`);
      }
    });
  };


  const getFeaturesByLicenseId = (licenseId) => {
    return new Promise((resolve, reject) => {
      console.log(`Fetching features for licenseId: ${licenseId}`);
      db.all(`SELECT * FROM features WHERE productMap IN (
              SELECT recordId FROM products WHERE entitlementMap IN (
              SELECT recordId FROM entitlements WHERE licenseMap IN (
              SELECT recordId FROM licenses WHERE licenseId = ?)))`, [licenseId], (err, rows) => {
        if (err) {
          console.error(`Error fetching features from database for licenseId ${licenseId}:`, err.message);
          reject(err);
        } else {
          console.log(`Successfully fetched ${rows.length} features for licenseId: ${licenseId}`);
          resolve(rows);
        }
      });
    });
  };


  async function updateLicenseDatabase(licenseContent) {
    const parsedLicense = await licenseParser(licenseContent);
    const userId = parsedLicense.userId;
    const licenseId = parsedLicense.id;

    db.run(`INSERT INTO licenses (userId, licenseId) VALUES (?, ?)`, [userId, licenseId], (err) => {
      if (err) {
        console.error('Error inserting license:', err.message);
      }
    });
  }


  const getFeatureDetails = (licenseId, featureId) => {
    return new Promise((resolve, reject) => {
      console.log(`Fetching feature details for licenseId: ${licenseId}, featureId: ${featureId}`);
      db.get(`SELECT * FROM features WHERE featureId = ? AND productMap IN (SELECT recordId FROM products WHERE entitlementMap IN (SELECT recordId FROM entitlements WHERE licenseMap IN (SELECT recordId FROM licenses WHERE licenseId = ?)))`, [featureId, licenseId], (err, row) => {
        if (err) {
          console.error(`Error fetching feature details from database for licenseId ${licenseId}, featureId ${featureId}:`, err.message);
          reject(err);
        } else if (row) {
          console.log(`Successfully fetched feature details for licenseId: ${licenseId}, featureId: ${featureId}`);
          resolve(row);
        } else {
          console.warn(`Feature not found for licenseId: ${licenseId}, featureId: ${featureId}`);
          resolve(null);
        }
      });
    });
  };

  const updateFeatureInDb = (feature, licenseId) => {
    return new Promise((resolve, reject) => {
      let updateQuery = '';
      let updateParams = [];

      // Construct the query and parameters based on the business model
      if (feature.businessModel === 'Trial') {
        updateQuery = `UPDATE features 
                     SET endDate = ? , startDate = ? 
                     WHERE featureId = ? 
                       AND productMap IN (
                         SELECT p.recordId 
                         FROM products p 
                         JOIN entitlements e ON p.entitlementMap = e.recordId 
                         WHERE e.licenseMap = (
                           SELECT recordId FROM licenses WHERE licenseId = ?
                         )
                       )`;
        updateParams = [feature.endDate, feature.startDate, feature.featureId, licenseId];
      } else if (feature.businessModel === 'ExecutionCount') {
        updateQuery = `UPDATE features 
                     SET consumedCount = ?, availableCount = ? 
                     WHERE featureId = ? 
                       AND productMap IN (
                         SELECT p.recordId 
                         FROM products p 
                         JOIN entitlements e ON p.entitlementMap = e.recordId 
                         WHERE e.licenseMap = (
                           SELECT recordId FROM licenses WHERE licenseId = ?
                         )
                       )`;
        updateParams = [feature.consumedCount, feature.availableCount, feature.featureId, licenseId];
      } else {
        // Handle other business models if necessary
        console.error(`Unsupported business model: ${feature.businessModel}`);
        return reject(`Unsupported business model: ${feature.businessModel}`);
      }

      console.log(`Executing update query for business model: ${feature.businessModel}`);
      db.run(updateQuery, updateParams, function (err) {
        if (err) {
          console.error(`Error updating feature in database: ${err.message}`);
          reject(err);
        } else {
          console.log(`Successfully updated feature in database: ${feature.featureId}`);
          resolve(true);
        }
      });
    });
  };


  // const getAllLicenseDetailsFromDb = () => {
  //   return new Promise((resolve, reject) => {
  //     db.serialize(() => {
  //       // Get all licenses
  //       db.all(`SELECT * FROM licenses`, (err, licenseRows) => {
  //         if (err) {
  //           console.error(`Error retrieving licenses: ${err.message}`);
  //           reject(err);
  //           return;
  //         }
  
  //         const licenses = licenseRows.map(license => ({
  //           userId: license.userId,
  //           licenseId: license.licenseId,
  //           entitlements: []
  //         }));
  //         console.log("Licenses fetched:", licenses);
  
  //         // Fetch entitlements for each license
  //         const fetchEntitlementsPromises = licenses.map(license => {
  //           return new Promise((entitlementResolve, entitlementReject) => {
  //             db.all(`SELECT * FROM entitlements WHERE licenseMap = (SELECT recordId FROM licenses WHERE licenseId = ?)`, [license.licenseId], (err, entitlementRows) => {
  //               if (err) {
  //                 console.error(`Error retrieving entitlements: ${err.message}`);
  //                 entitlementReject(err);
  //               } else {
  //                 const entitlements = entitlementRows.map(entitlement => ({
  //                   entitlementId: entitlement.entitlementId,
  //                   recordId: entitlement.recordId,
  //                   products: []
  //                 }));
  //                 license.entitlements = entitlements;
  //                 console.log(`Entitlements fetched for licenseId ${license.licenseId}:`, entitlements);
  
  //                 // Fetch products for each entitlement
  //                 const fetchProductsPromises = entitlements.map(entitlement => {
  //                   return new Promise((productResolve, productReject) => {
  //                     db.all(`SELECT * FROM products WHERE entitlementMap = ?`, [entitlement.recordId], (err, productRows) => {
  //                       if (err) {
  //                         console.error(`Error retrieving products for entitlementId ${entitlement.entitlementId}: ${err.message}`);
  //                         productReject(err);
  //                       } else {
  //                         const products = productRows.map(product => ({
  //                           productId: product.productId,
  //                           productName: product.productName,
  //                           features: []
  //                         }));
  //                         entitlement.products = products;
  //                         console.log(`Products fetched for entitlementId ${entitlement.entitlementId}:`, products);
  
  //                         // Fetch features for each product
  //                         const fetchFeaturesPromises = products.map(product => {
  //                           return new Promise((featureResolve, featureReject) => {
  //                             db.all(`SELECT * FROM features WHERE productMap = ?`, [product.recordId], (err, featureRows) => {
  //                               if (err) {
  //                                 console.error(`Error retrieving features for productId ${product.productId}: ${err.message}`);
  //                                 featureReject(err);
  //                               } else {
  //                                 product.features = featureRows.map(feature => ({
  //                                   featureId: feature.featureId,
  //                                   featureName: feature.featureName,
  //                                   businessModel: feature.businessModel,
  //                                   startDate: feature.startDate,
  //                                   endDate: feature.endDate,
  //                                   issuedCount: feature.issuedCount,
  //                                   consumedCount: feature.consumedCount,
  //                                   availableCount: feature.availableCount,
  //                                   noOfDays: feature.noOfDays
  //                                 }));
  //                                 console.log(`Features fetched for productId ${product.productId}:`, product.features);
  //                                 featureResolve();
  //                               }
  //                             });
  //                           });
  //                         });
  
  //                         Promise.all(fetchFeaturesPromises)
  //                           .then(() => productResolve())
  //                           .catch(err => productReject(err));
  //                       }
  //                     });
  //                   });
  //                 });
  
  //                 Promise.all(fetchProductsPromises)
  //                   .then(() => entitlementResolve())
  //                   .catch(err => entitlementReject(err));
  //               }
  //             });
  //           });
  //         });
  
  //         Promise.all(fetchEntitlementsPromises)
  //           .then(() => {
  //             // Flatten entitlements into the main license object
  //             const flattenedLicenses = licenses.flatMap(license => {
  //               return license.entitlements.map(entitlement => ({
  //                 userId: license.userId,
  //                 licenseId: license.licenseId,
  //                 entitlementId: entitlement.entitlementId,
  //                 products: entitlement.products
  //               }));
  //             });
  //             console.log("Final flattened licenses:", flattenedLicenses);
  //             resolve(flattenedLicenses);
  //           })
  //           .catch(err => reject(err));
  //       });
  //     });
  //   });
  // };
  const getAllLicenseDetailsFromDb = () => {
    return new Promise((resolve, reject) => {
      db.serialize(() => {
        // Get all licenses
        db.all(`SELECT * FROM licenses`, (err, licenseRows) => {
          if (err) {
            console.error(`Error retrieving licenses: ${err.message}`);
            reject(err);
            return;
          }
  
          const licenses = licenseRows.map(license => ({
            userId: license.userId,
            licenseId: license.licenseId,
            entitlements: []
          }));
          console.log("Licenses fetched:", licenses);
  
          // Fetch entitlements for each license
          const fetchEntitlementsPromises = licenses.map(license => {
            return new Promise((entitlementResolve, entitlementReject) => {
              db.all(`SELECT * FROM entitlements WHERE licenseMap = (SELECT recordId FROM licenses WHERE licenseId = ?)`, [license.licenseId], (err, entitlementRows) => {
                if (err) {
                  console.error(`Error retrieving entitlements: ${err.message}`);
                  entitlementReject(err);
                } else {
                  const entitlements = entitlementRows.map(entitlement => ({
                    entitlementId: entitlement.entitlementId,
                    recordId: entitlement.recordId,
                    products: []
                  }));
                  license.entitlements = entitlements;
                  console.log(`Entitlements fetched for licenseId ${license.licenseId}:`, entitlements);
  
                  // Fetch products for each entitlement
                  const fetchProductsPromises = entitlements.map(entitlement => {
                    return new Promise((productResolve, productReject) => {
                      db.all(`SELECT * FROM products WHERE entitlementMap = ?`, [entitlement.recordId], (err, productRows) => {
                        if (err) {
                          console.error(`Error retrieving products for entitlementId ${entitlement.entitlementId}: ${err.message}`);
                          productReject(err);
                        } else {
                          const products = productRows.map(product => ({
                            productId: product.productId,
                            recordId: product.recordId,
                            productName: product.productName,
                            features: []
                          }));
                          entitlement.products = products;
                          console.log(`Products fetched for entitlementId ${entitlement.entitlementId}:`, products);
  
                          // Fetch features for each product
                          const fetchFeaturesPromises = products.map(product => {
                            return new Promise((featureResolve, featureReject) => {
                              db.all(`SELECT * FROM features WHERE productMap = ?`, [product.recordId], (err, featureRows) => {
                                if (err) {
                                  console.error(`Error retrieving features for productId ${product.productId}: ${err.message}`);
                                  featureReject(err);
                                } else {
                                  const features = featureRows.map(feature => ({
                                    featureId: feature.featureId,
                                    featureName: feature.featureName,
                                    businessModel: feature.businessModel,
                                    startDate: feature.startDate,
                                    endDate: feature.endDate,
                                    issuedCount: feature.issuedCount,
                                    consumedCount: feature.consumedCount,
                                    availableCount: feature.availableCount,
                                    noOfDays: feature.noOfDays
                                  }));
                                  product.features = features;
                                  console.log(`Features fetched for productId ${product.productId}:`, features);
                                  featureResolve();
                                }
                              });
                            });
                          });
  
                          Promise.all(fetchFeaturesPromises)
                            .then(() => productResolve())
                            .catch(err => productReject(err));
                        }
                      });
                    });
                  });
  
                  Promise.all(fetchProductsPromises)
                    .then(() => entitlementResolve())
                    .catch(err => entitlementReject(err));
                }
              });
            });
          });
  
          Promise.all(fetchEntitlementsPromises)
            .then(() => {
              // Flatten entitlements into the main license object
              const flattenedLicenses = licenses.flatMap(license => {
                return license.entitlements.map(entitlement => ({
                  userId: license.userId,
                  licenseId: license.licenseId,
                  entitlementId: entitlement.entitlementId,
                  products: entitlement.products
                }));
              });
              console.log("Final flattened licenses:", flattenedLicenses);
              resolve(flattenedLicenses);
            })
            .catch(err => reject(err));
        });
      });
    });
  };
  


  // Export db and related functions only if the installation is not standalone 
  module.exports = {
    db,
    ensureTableExists,
    getLicenseIdByUserId,
    storeUserLicenseMapping,
    addEntitlementWithProductsAndFeatures,
    getFeaturesByLicenseId,
    updateLicenseDatabase,
    getFeatureDetails,
    updateFeatureInDb,
    getAllLicenseDetailsFromDb,
  };
} else {
  // If standalone installation, export dummy functions to avoid errors 
  module.exports = {
    ensureTableExists: async () => 'Standalone installation, database not used',
    getLicenseIdByUserId: async () => null,
    storeUserLicenseMapping: async () => null,
    addEntitlementWithProductsAndFeatures: async () => null,
    getFeaturesByLicenseId: async () => [],
    updateLicenseDatabase: async () => null,
    getFeatureDetails: async () => null,
    updateFeatureInDb: async () => null,
    getAllLicenseDetailsFromDb: async () => null,
  };
}