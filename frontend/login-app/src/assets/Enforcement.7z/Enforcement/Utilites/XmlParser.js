const xml2js = require('xml2js');
var { LicenseModel } = require("./../Models/LicenseModel")
const Feature = require("./../Models/Feature")
const Product = require("./../Models/Product")
const Entitlement = require("./../Models/Entitlement")

let featuresList = [];
let productsList = [];
let entitlementList;
let Lid;

// Function to parse license XML content
async function licenseParser(xmlContent) {
    const parser = new xml2js.Parser();
    const result = await parser.parseStringPromise(xmlContent);
    const licenseInfo = result.license.license_info[0];
    LicenseModel = {
        id: licenseInfo.$.id,
        userId: licenseInfo.$.userId,
        version:licenseInfo.$.version,
        license: licenseInfo.lic[0],
    };

    Lid = LicenseModel.id
    return LicenseModel;
}


async function getFeature() {
    return featuresList
}

async function getProduct() {
    return productsList
}


async function getEntitlement() {
    return entitlementList
}

async function getLicenseId() {
    return Lid
}


async function entitlementParser(xmlContent) {
    featuresList = [];
    productsList = [];
    try {
        const parser = new xml2js.Parser();
        const result = await parser.parseStringPromise(xmlContent);
        const entitlements = result.entitlement;

        const entitlement = new Entitlement(
            entitlements.$.entitlementId,
            entitlements.$.timestamp,
            []
        );

        const productList = entitlements.productList[0].product;
        productList.forEach(productElement => {
            const product = new Product(
                parseInt(productElement.$.productId, 10),
                productElement.$.productName,
                []
            );

            const featureList = productElement.featureList[0].feature;
            featureList.forEach(featureElement => {
                let businessModel;
                let startDate = "", issuedCount = "", consumedCount = "", availableCount = "", endDate = "", noOfDays = "";
                const currentDate = new Date().toISOString();

                switch (featureElement.$.businessModel) {
                    case "Perpetual":
                        businessModel = "Perpetual";
                        startDate = featureElement.$.startDate || currentDate;
                        break;
                    case "Subscription":
                        businessModel = "Subscription";
                        startDate = featureElement.$.startDate || currentDate;
                        endDate = featureElement.$.endDate || "";
                        break;
                    case "ExecutionCount":
                        businessModel = "ExecutionCount";
                        startDate = featureElement.$.startDate || currentDate;
                        issuedCount = parseInt(featureElement.$.issuedCount, 10) || 0;
                        consumedCount = parseInt(featureElement.$.consumedCount, 10) || 0;
                        availableCount = parseInt(featureElement.$.availableCount, 10) || 0;
                        break;
                    case "Trial":
                        businessModel = "Trial";
                        startDate = featureElement.$.startDate ;
                        endDate = featureElement.$.endDate || "";
                        noOfDays = parseInt(featureElement.$.noOfDays, 10) || 0;
                        break;
                    default:
                        businessModel = "";
                }

                const feature = new Feature(
                    featureElement.$.featureId,
                    featureElement.$.featureName,
                    featureElement.$.enable === 'true',
                    businessModel,
                    startDate,
                    issuedCount,
                    consumedCount,
                    availableCount,
                    endDate,
                    noOfDays
                );

                // console.log(feature);
                featuresList.push(feature);
                product.features.push(feature);
            });

            productsList.push(product);
            entitlement.products.push(product);
        });

        entitlementList = entitlement;
        // console.log("entitlementList-----", entitlementList);
        return entitlementList;
    } catch (error) {
        console.error('Error parsing XML:', error);
        return entitlementList;
    }
}

// Function to parse fingerprint XML content
async function fingerprintParser(xmlContent) {
    const parser = new xml2js.Parser();
    const result = await parser.parseStringPromise(xmlContent);
    const fingerprint = result.encrypted_data.fingerprint[0].host_fp[0];
    return fingerprint;
}

module.exports = {
    licenseParser,
    entitlementParser,
    fingerprintParser,
    getProduct,
    getFeature,
    getEntitlement,
    getLicenseId
};
