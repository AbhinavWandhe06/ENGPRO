// Function to open the navigation popup
function openNavPopup() {
  document.getElementById("navPopup").style.display = "block";
} // Function to close the navigation popup
function closeNavPopup() {
  document.getElementById("navPopup").style.display = "none";
}

// Function to handle tab switching
function openTab(evt, tabName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(tabName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Set default tab to open
document.addEventListener("DOMContentLoaded", function () {
  document.querySelector(".tablink").click();
});

// showNotification function to accept a type parameter
function showNotification(message, type = "info") {
  const notification = document.getElementById("notification");
  notification.className = `notification ${type}`;
  notification.textContent = message;
  notification.style.display = "block";
  notification.style.opacity = "1";

  setTimeout(() => {
    notification.style.opacity = "0";
    setTimeout(() => {
      notification.style.display = "none";
    }, 500);
  }, 3000);
}

document
  .getElementById("generateFingerprint")
  .addEventListener("click", async (event) => {
    event.preventDefault();
    try {
      const response = await fetch("/api/generateFingerprint", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ inputValue: true }),
      });
      const data = await response.json();
      const fingerprint = data.outputValue;

      // Format the timestamp
      const timestamp = dayjs().format("YYYYMMDD_HHmmss"); // Desired format
      const filename = `Fingerprint_${timestamp}.lfp`;
      const blob = new Blob([fingerprint], { type: "text/plain" });

      // Create a URL for the blob
      const url = URL.createObjectURL(blob);

      // Directly trigger download
      const downloadLink = document.createElement("a");
      downloadLink.href = url; // Set the href to the blob URL
      downloadLink.download = filename; // Set the filename for download
      downloadLink.click(); // Trigger the download

      showNotification(
        "Fingerprint generated successfully! The file is downloading."
      );
    } catch (error) {
      console.error("Error generating fingerprint:", error);
      showNotification("Failed to generate fingerprint. Please try again.");
    }
  });

document.getElementById("uploadLicense").addEventListener("click", async () => {
  const fileInput = document.getElementById("licenseFile");
  const file = fileInput.files[0];

  if (!file) {
    showNotification("Please select a license file to upload.");
    return;
  }

  const reader = new FileReader();
  reader.onload = async (event) => {
    const fileContent = event.target.result;

    try {
      const response = await fetch("/uploadLicense", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ licenseContent: fileContent }),
      });

      const result = await response.json();
      showNotification(result.message);

      fileInput.value = ""; // Reset the file input
    } catch (error) {
      console.error("Error uploading license:", error);
      fileInput.value = "";
      showNotification("Failed to upload license. Please try again.");
    }
  };
  reader.readAsText(file);
});

function showSpinner() {
  document.getElementById("loadingSpinner").style.display = "block";
}

function hideSpinner() {
  document.getElementById("loadingSpinner").style.display = "none";
}

document.addEventListener("DOMContentLoaded", async () => {
  await fetchAllLicenses();
});

async function fetchConfig() {
  try {
    const response = await fetch("/config");
    const config = await response.json();
    return config;
  } catch (error) {
    console.error("Error fetching configuration:", error);
    return { standalone_Installation: "false" }; // Default value
  }
}

async function fetchAllLicenses() {
  try {
    const response = await fetch("/allLicenseInfo", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    });

    const data = await response.json();
    const config = await fetchConfig();
    displayEntitlements(data.licenses, config.standalone_Installation);
  } catch (error) {
    console.error("Error fetching all license information:", error);
    showNotification(
      "Failed to fetch all license information. Please try again."
    );
  }
}

function displayEntitlements(licenses, standaloneInstallation) {
  const showUserId = standaloneInstallation !== "true";
  const licenseInfoContainer = document.getElementById("licenseInfoContainer");
  licenseInfoContainer.innerHTML = `
    <table class="license-table">
      <thead>
        <tr>
        ${showUserId ? "<th>User ID</th>" : ""}
          <th>License ID</th>
          <th>Entitlement ID</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
      ${licenses
        .map(
          (entitlement) => ` 
        <tr onclick="showProducts('${entitlement.entitlementId}', '${
            entitlement.licenseId
          }')"> 
          ${showUserId ? `<td>${entitlement.userId}</td>` : ""}
          <td>${entitlement.licenseId}</td> 
          <td>${entitlement.entitlementId}</td> 
          <td>
            <a href="#" onclick="generateUpdateFingerprint(event, '${
              entitlement.licenseId
            }')"> 
              <i class="fas fa-sync-alt"></i> Generate Update Fingerprint 
            </a> 
          </td> 
        </tr> 
        `
        )
        .join("")}
      </tbody>
    </table>
  `;

  // Store licenses data for later use
  window.licensesData = licenses;
}

function showProducts(entitlementId, licenseId) {
  const entitlement = window.licensesData.find(
    (e) => e.entitlementId === entitlementId && e.licenseId === licenseId
  );
  const licenseInfoContainer = document.getElementById("licenseInfoContainer");
  licenseInfoContainer.innerHTML = `
    <h3>License ID: ${licenseId}</h3>
    <h3>Entitlement ID: ${entitlement.entitlementId}</h3>
    <table class="license-table">
      <thead>
        <tr>
          <th>Product ID</th>
          <th>Product Name</th>
        </tr>
      </thead>
      <tbody>
        ${entitlement.products
          .map(
            (product) => `
          <tr onclick="showFeatures('${entitlement.entitlementId}', '${product.productId}', '${licenseId}')">
            <td>${product.productId}</td>
            <td>${product.productName}</td>
          </tr>
        `
          )
          .join("")}
      </tbody>
    </table>
    <button onclick="displayEntitlements(window.licensesData)">Back to Entitlements</button>
  `;
}

const formatDateFromEpoch = (epochTime) => {
  if (!epochTime || isNaN(epochTime)) return "";
  const date = new Date(parseInt(epochTime));
  return date.toISOString();
};
function showFeatures(entitlementId, productId, licenseId) {
  const entitlement = window.licensesData.find(
    (e) => e.entitlementId === entitlementId && e.licenseId === licenseId
  );
  const product = entitlement.products.find((p) => p.productId == productId);
  const licenseInfoContainer = document.getElementById("licenseInfoContainer");
  licenseInfoContainer.innerHTML = `
    <h3>Product ID: ${product.productId}</h3>
    <p>Product Name: ${product.productName}</p>
    <table class="license-table">
      <thead>
        <tr>
          <th>Feature ID</th>
          <th>Feature Name</th>
          <th>Business Model</th>
          <th>Start Date</th>
          <th>End Date</th>
          <th>Issued Count</th>
          <th>Consumed Count</th>
          <th>Available Count</th>
          <th>No of Days</th>
        </tr>
      </thead>
      <tbody>
        ${product.features
          .map(
            (feature) => `
          <tr>
            <td>${feature.featureId}</td>
            <td>${feature.featureName}</td>
            <td>${feature.businessModel}</td>
            <td>${feature.startDate}</td>
            <td>${formatDateFromEpoch(feature.endDate)}</td>
            <td>${feature.issuedCount}</td>
            <td>${feature.consumedCount}</td>
            <td>${feature.availableCount}</td>
            <td>${feature.noOfDays}</td>
          </tr>
        `
          )
          .join("")}
      </tbody>
    </table>
    <button onclick="showProducts('${
      entitlement.entitlementId
    }', '${licenseId}')">Back to Products</button>
  `;
}

async function generateUpdateFingerprint(e, licenseId) {
  // Prevent the row click event

  e.stopPropagation();
  try {
    const response = await fetch(
      `/generateUpdateFingerprint?licenseId=${licenseId}`,
      {
        method: "POST",
      }
    );
    const data = await response.json();
    const fingerprint = data.fingerprint;

    // Format the timestamp
    const timestamp = dayjs().format("YYYYMMDD_HHmmss"); // Desired format
    const filename = `UpdateFingerprint_${timestamp}.lfp`;
    const blob = new Blob([fingerprint], { type: "text/plain" });

    // Create a URL for the blob
    const url = URL.createObjectURL(blob);

    // Directly trigger download
    const downloadLink = document.createElement("a");
    downloadLink.href = url; // Set the href to the blob URL
    downloadLink.download = filename; // Set the filename for download
    downloadLink.click(); // Trigger the download

    showNotification(
      "Update fingerprint generated successfully! The file is downloading."
    );
  } catch (error) {
    console.error("Error generating update fingerprint:", error);
    showNotification(
      "Failed to generate update fingerprint. Please try again."
    );
  }
}

// Fetch and display all sessions
async function fetchAllSessions() {
  try {
    const response = await fetch("/getAllSessions", {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });

    const data = await response.json();
    const config = await fetchConfig();
    displaySessions(data.sessions, config.standalone_Installation);
  } catch (error) {
    console.error("Error fetching all sessions:", error);
    showNotification("Failed to fetch all sessions. Please try again.");
  }
}

// Display sessions
function displaySessions(sessions, standaloneInstallation) {
  const showUserId = standaloneInstallation !== "true";
  const sessionsInfoContainer = document.getElementById(
    "sessionsInfoContainer"
  );
  sessionsInfoContainer.innerHTML = `
    <table class="sessions-table">
      <thead>
        <tr>
          <th>Session ID</th>
          <th>feature ID</th>
          ${showUserId ? "<th>User ID</th>" : ""}
          <th>License ID</th>
          <th>Start Time</th>
        </tr>
      </thead>
      <tbody>
        ${sessions
          .map(
            (session) => `
          <tr>
            <td>${session.sessionId}</td>
            <td>${session.featureID}</td>
            ${showUserId ? `<td>${session.userId}</td>` : ""}
            <td>${session.licenseId}</td>
            <td>${session.timestamp}</td>
          </tr>
        `
          )
          .join("")}
      </tbody>
    </table>
  `;
}

// Function to handle tab switching
function openTab(evt, tabName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(tabName).style.display = "block";
  evt.currentTarget.className += " active";

  // Fetch data for the tab if needed
  if (tabName === "LicenseInfo") {
    fetchAllLicenses();
  } else if (tabName === "SessionsOpen") {
    fetchAllSessions();
  }
}

// Set default tab to open
document.addEventListener("DOMContentLoaded", function () {
  document.querySelector(".tablink").click();
});
