const grpc = require("@grpc/grpc-js");
const protoLoader = require("@grpc/proto-loader");
const path = require("path");
const express = require("express");
const fs = require("fs");
const { serverLogger } = require("./Utilites/ServerLogging");
const services = require("./Services/services");
const { licenseParser, entitlementParser } = require("./Utilites/XmlParser");
const {
  getFingerprint,
  saveFingerprintToXML,
  GenerateUpdatedLicenseXML,
} = require("./Utilites/FingerprintUtil");
const {
  isLicenseValid,
  LicenseDirectory,
  getAllLicense,
  extractLicenseInfo,
} = require("./Utilites/LicenseUtil");
const {
  db,
  ensureTableExists,
  getAllLicenseDetailsFromDb,
} = require("./Utilites/Database");
const {
  storeUserLicenseMapping,
  addEntitlementWithProductsAndFeatures,
} = require("./Utilites/Database");
const config = require("./config.json");
const { getAllSession } = require("./Utilites/SessionManagement");
const { decrypt } = require("./Utilites/EncryptDecryptUtil");

// Load the .proto file
const PROTO_PATH = path.join(__dirname, "protos", "example.proto");
const packageDefinition = protoLoader.loadSync(PROTO_PATH, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});
const proto = grpc.loadPackageDefinition(packageDefinition).example;

// Create an Express app
const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Middleware to serve static files (like your HTML and JS)
app.use(express.static(path.join(__dirname, "public"))); // Assuming your HTML and JS are in a 'public' folder

async function loadAllLicenses() {
  //see this impotant
  console.log("loadAllLicenses function called");
  const licenseDir = path.join(__dirname, "License/Centralized");
  const licenseFiles = fs
    .readdirSync(licenseDir)
    .filter((file) => file.endsWith(".lic"));

  // Group files by the first 18 characters of their name
  const fileGroups = licenseFiles.reduce((groups, file) => {
    const baseName = file.substring(0, 18); // Adjust if the base name length differs
    if (!groups[baseName]) {
      groups[baseName] = [];
    }
    groups[baseName].push(file);
    return groups;
  }, {});

  for (const baseName in fileGroups) {
    const files = fileGroups[baseName];

    // Find the file with the highest suffix number
    const highestFile = files.reduce((maxFile, file) => {
      const suffix = getSuffixNumber(file);
      const maxSuffix = getSuffixNumber(maxFile);
      return suffix > maxSuffix ? file : maxFile;
    }, files[0]);

    const filePath = path.join(licenseDir, highestFile);
    const licenseContent = fs.readFileSync(filePath, "utf8");
    const parsedLicense = await licenseParser(licenseContent);
    const userId = parsedLicense.userId;
    const licenseId = parsedLicense.id;
    const licensefileContent = parsedLicense.license;
    const Base64LicenseInfo = Buffer.from(licensefileContent, "base64");
    const decryptedLicenseInfo = await decrypt(
      Base64LicenseInfo.toString("hex")
    );

    const start = decryptedLicenseInfo.indexOf("<entitlement");
    const end =
      decryptedLicenseInfo.indexOf("</entitlement>") + "</entitlement>".length;
    const relevantXmlContent = decryptedLicenseInfo.substring(start, end);
    // console.log("relevantXmlContent", relevantXmlContent)
    const EntitlementParser = await entitlementParser(relevantXmlContent);
    // console.log("EntitlementParser", EntitlementParser)
    const entitlement = await extractLicenseInfo(
      EntitlementParser,
      licenseId,
      userId
    );

    console.log(`Parsed License - userId: ${userId}, licenseId: ${licenseId}`);

    // Use the storeUserLicenseMapping function
    try {
      await storeUserLicenseMapping(userId, licenseId);
      console.log(
        `License inserted/updated: userId=${userId}, licenseId=${licenseId}`
      );
      // Use the addEntitlementWithProductsAndFeatures function to store details in the database
      await addEntitlementWithProductsAndFeatures(
        licenseId,
        entitlement.entitlementId,
        entitlement.products
      );
      // console.log(`License inserted/updated: userId=${userId}, licenseId=${licenseId}`);
    } catch (err) {
      console.error("Error inserting license:", err.message);
    }
  }
  console.log("All licenses loaded into the database.");
}

// Function to extract the suffix number from the file name
function getSuffixNumber(fileName) {
  const parts = fileName.split("_");
  const suffix = parts.length > 1 ? parseInt(parts[1].split(".")[0], 10) : 0;
  return isNaN(suffix) ? 0 : suffix;
}

//Route to generate fingerprint
// app.post("/generateFingerprint", async (req, res) => {
//   try {
//     const fp = await getFingerprint(); // Call the function from Fingerprint.js
//     const fingerprint = await saveFingerprintToXML(fp); // Save to XML if needed
//     res.json({ fingerprint }); // Send the fingerprint in the response
//   } catch (error) {
//     serverLogger.error(`Error generating fingerprint: ${error.message}`);
//     res.status(500).json({ message: "Error generating fingerprint" });
//   }
// });

const client = new proto.ExampleService(
  "127.0.0.1:50051",
  grpc.credentials.createInsecure()
);

async function GenerateFingerprint(req, res) {
  client.GenerateFingerprint({ inputValue: true }, (err, response) => {
    if (err) {
      res.status(500).send(err);
    } else {
      res.send(response);
    }
  });
}
app.post("/api/generateFingerprint", GenerateFingerprint);

app.post("/generateUpdateFingerprint", async (req, res) => {
  try {
    const licenseId = req.query.licenseId; // Get licenseId from query params
    const fp = await getFingerprint();
    const fingerprint = await GenerateUpdatedLicenseXML(fp, licenseId); // Call the function from Fingerprint.js
    res.json({ fingerprint }); // Send the fingerprint in the response
  } catch (error) {
    serverLogger.error(`Error generating update fingerprint: ${error.message}`);
    res.status(500).json({ message: "Error generating update fingerprint" });
  }
});

// Route to upload license
app.post("/uploadLicense", async (req, res) => {
  try {
    console.log(req.body); // Log the entire body
    const licenseContent = req.body.licenseContent;
    if (!licenseContent) {
      return res.status(400).json({ message: "License content is missing." });
    }

    const isValid = await isLicenseValid(licenseContent);
    if (isValid) {
      const parsedLicense = await licenseParser(licenseContent);
      const userId = parsedLicense.userId;
      const licenseId = parsedLicense.id;
      const licensefileContent = parsedLicense.license;
      const Base64LicenseInfo = Buffer.from(licensefileContent, "base64");
      const decryptedLicenseInfo = await decrypt(
        Base64LicenseInfo.toString("hex")
      );

      const start = decryptedLicenseInfo.indexOf("<entitlement");
      const end =
        decryptedLicenseInfo.indexOf("</entitlement>") +
        "</entitlement>".length;
      const relevantXmlContent = decryptedLicenseInfo.substring(start, end);
      // console.log("relevantXmlContent", relevantXmlContent)
      const EntitlementParser = await entitlementParser(relevantXmlContent);
      // console.log("EntitlementParser", EntitlementParser)
      const entitlement = await extractLicenseInfo(
        EntitlementParser,
        licenseId,
        userId
      );

      console.log(
        `Uploading License - userId: ${userId}, licenseId: ${licenseId}`
      );

      try {
        await storeUserLicenseMapping(userId, licenseId);
        console.log(
          `License inserted/updated: userId=${userId}, licenseId=${licenseId}`
        );

        // Use addEntitlementWithProductsAndFeatures to store details in the database
        await addEntitlementWithProductsAndFeatures(
          licenseId,
          entitlement.entitlementId,
          entitlement.products
        );
        console.log(
          `Entitlements and products inserted/updated for licenseId=${licenseId}`
        );
        res.json({ message: "License uploaded and stored successfully!" });
      } catch (err) {
        console.error(
          "Error inserting entitlements and products:",
          err.message
        );
        res
          .status(500)
          .json({ message: "Error inserting entitlements and products" });
      }
    } else {
      res.status(400).json({ message: "Invalid license!" });
    }
  } catch (error) {
    serverLogger.error(`Error uploading license: ${error.message}`);
    res.status(500).json({ message: "Error uploading license" });
  }
});

// Route to fetch license information
app.post("/allLicenseInfo", async (req, res) => {
  try {
    if (config.standalone_Installation === "true") {
      const allLicenses = await getAllLicense();
      console.log("gsds", allLicenses);
      res.json({ licenses: allLicenses });
    } else {
      const allLicenses = await getAllLicenseDetailsFromDb();
      console.log("gdfgd", allLicenses);
      res.json({ licenses: allLicenses });
    }
  } catch (error) {
    serverLogger.error(
      `Error fetching all license information: ${error.message}`
    );
    res.status(500).json({
      message: `Error fetching all license information: ${error.message}`,
    });
  }
});

//route to fetch config.json info
app.get("/config", (req, res) => {
  res.json({ standalone_Installation: config.standalone_Installation });
});

// Route to fetch all sessions
app.get("/getAllSessions", async (req, res) => {
  try {
    const allSessions = await getAllSession();
    res.json({ sessions: allSessions });
  } catch (error) {
    serverLogger.error(`Error fetching sessions: ${error.message}`);
    res
      .status(500)
      .json({ message: `Error fetching sessions: ${error.message}` });
  }
});

// Serve the admin HTML page
app.get("/admin", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "admin.html")); // Adjust the path if necessary
});

// Create a gRPC server and bind it to the Express app
const server = new grpc.Server();
serverLogger.info("Server created");

// Register services with the server
// server.addService(proto.ExampleService.service, services);

server.addService(proto.ExampleService.service, {
  GenerateFingerprint: async (call, callback) => {
    try {
      const response = await generateFingerprint(call.request);
      callback(null, response);
    } catch (error) {
      console.error("GenerateFingerprint error:", error);
      callback({
        code: grpc.status.INTERNAL,
        message: "Failed to generate fingerprint",
      });
    }
  },
});

// Start the combined server
const PORT = process.env.PORT || 50051;
const serverCredentials = grpc.ServerCredentials.createInsecure();

app.listen(PORT, async () => {
  serverLogger.info(`Admin control server running at http://localhost:${PORT}`);
  try {
    if (config.standalone_Installation === "false") {
      const tableCreationMessage = await ensureTableExists(); // Ensure the table exists before loading licenses
      console.log(tableCreationMessage);
      await loadAllLicenses();
      serverLogger.info("All licenses loaded into the database.");
    }
  } catch (error) {
    console.error("Error ensuring table exists:", error);
  }
});

server.bindAsync(`10.36.1.129:${PORT}`, serverCredentials, (err, port) => {
  if (err) {
    serverLogger.error(`Failed to bind server: ${err.message}`);
    return;
  }
  serverLogger.info(`gRPC server running at 10.36.1.129:${port}`);
});

// Close the database connection when the server shuts down
if (config.standalone_Installation !== "true") {
  process.on("exit", () => {
    db.close((err) => {
      if (err) {
        console.error("Error closing database:", err.message);
      } else {
        console.log("Database connection closed.");
      }
    });
  });
}
