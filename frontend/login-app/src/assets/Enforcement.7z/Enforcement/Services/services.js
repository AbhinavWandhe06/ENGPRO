// const path = require("path");
const grpc = require("@grpc/grpc-js");
const protoLoader = require("@grpc/proto-loader");
const dayjs = require("dayjs");
const { serverLogger } = require("./../Utilites/ServerLogging");
const {
  getFingerprint,
  saveFingerprintToXML,
  // isLicenseValid,
  GenerateUpdatedLicenseXML, // LicenseDirectory,
} = require("../Utilites/FingerprintUtil");
const {
  isLicenseValid,
  LicenseDirectory,
  LicenseObjectStorage,
  getAllLicense,
} = require("./../Utilites/LicenseUtil");
const xml2js = require("xml2js");
const fs = require("fs");
const path = require("path");
const {
  ExecutionCount,
  Trial,
  Perpetual,
  Subscription,
} = require("./../Utilites/ModelChecking");
const { getProduct } = require("./../Utilites/XmlParser");
const {
  getLicenseIdByUserId,
  getFeaturesByLicenseId,
  getFeatureDetails,
  updateLicenseDatabase,
} = require("./../Utilites/Database");
const {
  startSession,
  closeFeatureInSession,
} = require("./../Utilites/SessionManagement");
const config = require("./../config.json");

// Implement the SayHello function
function SayHello(call, callback) {
  const replyMessage = `Hello, ${call.request.name}!`;
  serverLogger.info(`SayHello called with name: ${call.request.name}`);
  callback(null, { message: replyMessage });
}

// Implement TestServer function
async function TestServer(call, callback) {
  try {
    if (call.request.inputValue) {
      const testMessage = "hello";
      serverLogger.info("TestServer called with inputValue.");
      callback(null, { outputValue: testMessage });
    } else {
      serverLogger.warn("TestServer called without inputValue.");
      callback({
        code: grpc.status.INVALID_ARGUMENT,
        message: "inputValue is required",
      });
    }
  } catch (error) {
    serverLogger.error(`Error in TestServer: ${error.message}`);
    callback({
      code: grpc.status.INTERNAL,
      message: `Error processing request: ${error.message}`,
    });
  }
}

// Load the .proto file
const PROTO_PATH = path.join(__dirname, "./../protos/example.proto");
const packageDefinition = protoLoader.loadSync(PROTO_PATH, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});

// Implement the GenerateFingerprint function
async function GenerateFingerprint(call, callback) {
  return new Promise((resolve, reject) => {
    const request = { inputValue: true };
    client.GenerateFingerprint(request, (error, response) => {
      if (error) {
        console.error("Error in   GenerateFingerprint:", error);
        reject(new Error("Failed to generate fingerprint"));
      } else {
        console.log("GenerateFingerprint response:", response);
        resolve(response.outputValue);
      }
    });
  });
}

// Implement the GenerateUpdateFingerprint function
async function GenerateUpdateFingerprint(call, callback) {
  console.time("GenerateUpdateFingerprint");
  try {
    if (call.request.inputValue) {
      const fingerprint = await getFingerprint();
      const result = await GenerateUpdatedLicenseXML(fingerprint);
      console.log("hfjdgdjf", result);
      serverLogger.info(result);
      serverLogger.info("GenerateUpdateFingerprint called.");

      callback(null, { outputValue: result });
      console.timeEnd("GenerateUpdateFingerprint");
    } else {
      serverLogger.warn("GenerateFingerprint called without inputValue.");
      callback({
        code: grpc.status.INVALID_ARGUMENT,
        message: "inputValue is required",
      });
    }
  } catch (error) {
    serverLogger.error(`Error in GenerateFingerprint: ${error.message}`);
    callback({
      code: grpc.status.INTERNAL,
      message: `Error generating fingerprint: ${error.message}`,
    });
  }
}

// Implement the Installation function
async function Installation(call, callback) {
  console.time("Installation");
  try {
    const fileContent = call.request.inputValue;
    serverLogger.info("fileContent: ", call.request.inputValue);
    if (!fileContent || fileContent.trim() === "") {
      serverLogger.warn("Installation called with empty file content.");
      callback(null, { outputValue: "Invalid: File content is empty" });
      return;
    }

    const isValid = await isLicenseValid(fileContent);
    console.timeEnd("Installation");
    if (isValid) {
      serverLogger.info("Installation successful.");

      // Update the database only if the installation is centralized
      if (config.standalone_Installation !== "true") {
        await updateLicenseDatabase(fileContent);
      }
      callback(null, { outputValue: "Valid" });
    } else {
      serverLogger.warn("Installation failed: License is not valid.");
      callback(null, { outputValue: "Invalid" });
    }
  } catch (error) {
    serverLogger.error(`Error in Installation: ${error.message}`);
    callback({
      code: grpc.status.INTERNAL,
      message: `Error processing installation: ${error.message}`,
    });
  }
}

// Implement the GetAllFeature method
async function GetAllFeature(call, callback) {
  let { userId } = call.request;
  console.log("fff", typeof userId);
  let { licenseId } = call.request;
  const featureReply = { outputValue: false, FeatureList: [] };
  let license;
  try {
    if (config.standalone_Installation === "true") {
      // Standalone installation: get features from stored licenses
      const allStoredLicenses = await getAllLicense();

      if (licenseId) {
        license = allStoredLicenses.find((l) => l.licenseId === licenseId);
      }

      if (!license) {
        license = await LicenseObjectStorage(licenseId);
      }
      if (license) {
        const featureslist = license.products.flatMap(
          (product) => product.features
        );
        featureReply.outputValue = true;
        featureReply.FeatureList = featureslist.map((feature) => ({
          featureId: feature.featureId,
          featureName: feature.featureName,
        }));
        console.log("Features list:", featureReply.FeatureList);
      } else {
        console.warn("License not found for licenseId:", licenseId);
      }
      if (featureReply.FeatureList.length === 0) {
        console.warn("Feature list is empty for licenseId:", licenseId);
      }
    } else {
      // Centralized installation: get features from the database
      if (userId && userId.trim() !== "") {
        licenseId = await getLicenseIdByUserId(userId);
        if (!licenseId) {
          console.warn(`No license found for userId: ${userId}`);
          callback(null, featureReply);
          return;
        }
      }

      const featureslist = await getFeaturesByLicenseId(licenseId);
      console.log("Features list from database:", featureslist);
      if (featureslist.length === 0) {
        console.warn("No features found for licenseId:", licenseId);
      } else {
        featureReply.outputValue = true;
        featureReply.FeatureList = featureslist.map((feature) => ({
          featureId: feature.featureId,
          featureName: feature.featureName,
        }));
      }
    }
    callback(null, featureReply);
  } catch (error) {
    console.error("Error in GetAllFeature:", error);
    callback({
      code: grpc.status.INTERNAL,
      message: error.message,
    });
  }
}

// Implement the GetAllProducts method
// async function GetAllProduct(call, callback) {
//   const productReply = { outputValue: [] };
//   try {
//     const filePath = path.join(__dirname, "./../License/NewLicenseFile.lic");
//     const flag = fs.existsSync(filePath);
//     if (flag) {
//       const licenseContent = fs.readFileSync(filePath, "utf8");
//       await isLicenseValid(licenseContent);

//       // await entitlementExtractor();
//       const productlist = await getProduct();
//       // console.log('GetAllFeature called', featurelist);

//       if (productlist.length === 0) {
//         console.warn("productslist is empty");
//       } else {
//         productReply.outputValue = productlist;
//       }
//       //console.log('GetAllFeature response:', featureReply);
//       callback(null, productReply);
//     } else {
//       productReply.outputValue = [];
//       //console.log('GetAllFeature response:', featureReply);
//       callback(null, productReply);
//     }
//   } catch (error) {
//     console.error("Error in GetAllFeature:", error);
//     callback({
//       code: grpc.status.INTERNAL,
//       message: error.message,
//     });
//   }
// }

// Implement the GetRequestedFeature method
async function GetRequestedFeature(call, callback) {
  const { featureId, userId } = call.request;
  let { licenseId } = call.request;
  const featureReply = { feature: {}, SessionId: "" };
  let featureFound = false;

  try {
    let featureDetails;
    let license;

    if (config.standalone_Installation === "true") {
      // Standalone installation: get license from stored licenses
      const allStoredLicenses = await getAllLicense();
      if (licenseId) {
        license = allStoredLicenses.find((l) => l.licenseId === licenseId);
      }
      if (!license) {
        license = await LicenseObjectStorage(licenseId);
      }
      if (license) {
        featureDetails = license.products
          .flatMap((product) => product.features)
          .find((feature) => feature.featureId === featureId);
      } else {
        console.warn(`License not found for licenseId: ${licenseId}`);
        callback({
          code: grpc.status.NOT_FOUND,
          message: "License not found",
        });
        return;
      }
    } else {
      // Centralized installation: get feature details from the database
      if (userId && userId.trim() !== "") {
        licenseId = await getLicenseIdByUserId(userId);
        if (!licenseId) {
          console.warn(`No license found for userId: ${userId}`);
          callback(null, featureReply);
          return;
        }
      }

      featureDetails = await getFeatureDetails(licenseId, featureId);
    }
    console.log("Feature details fetched:", featureDetails);
    if (!featureDetails) {
      console.warn(
        `Feature not found for featureId: ${featureId}, licenseId: ${licenseId}`
      );
      callback({ code: grpc.status.NOT_FOUND, message: "Feature not found" });
      return;
    } else {
      featureFound = true;

      switch (featureDetails.businessModel) {
        case "Perpetual":
          console.log("Perpetual found:", featureDetails.businessModel);
          await Perpetual(featureDetails, licenseId);
          break;
        case "Subscription":
          console.log("Subscription found:", featureDetails.businessModel);
          await Subscription(featureDetails, licenseId);
          break;
        case "ExecutionCount":
          console.log("ExecutionCount found:", featureDetails.businessModel);
          featureFound = await ExecutionCount(featureDetails, licenseId);
          break;
        case "Trial":
          console.log("Trial found:", featureDetails.businessModel);
          await Trial(featureDetails, licenseId);
          break;
        default:
          console.warn("Unknown business model:", featureDetails.businessModel);
      }
    }

    if (!featureFound) {
      console.warn("Feature not found for featureId:", featureId);
      return callback({
        code: grpc.status.NOT_FOUND,
        message: "Feature not found",
      });
    }

    // Start a session for the requested feature
    const sessionId = await startSession(
      featureDetails.featureId,
      userId,
      licenseId
    );
    featureReply.SessionId = sessionId;
    featureReply.feature = featureDetails;

    console.log("Feature details:", featureReply.feature);
    callback(null, featureReply);
  } catch (error) {
    console.error("Error in GetRequestedFeature:", error);
    callback({
      code: grpc.status.INTERNAL,
      message: error.message,
    });
  }
}

async function ReleaseFeature(call, callback) {
  console.log("call", call.request);
  const SessionId = call.request.SessionId;
  const featureId = call.request.featureId;
  // console.log("iyiuktugg",SessionId,"\n",featureId)
  try {
    await closeFeatureInSession(SessionId, featureId);
    console.log(`Session ${SessionId} closed for feature ${featureId}`);
    serverLogger.info(`Session ${SessionId} closed for feature ${featureId}`);

    const response = { message: "Session closed successfully" };
    console.log("ReleaseFeature response:", response); // Print the response to the console

    callback(null, response);
  } catch (error) {
    console.error(`Error in LogOut: ${error.message}`);
    serverLogger.error(`Error in LogOut: ${error.message}`);
    callback({
      code: grpc.status.INTERNAL,
      message: `Error closing session: ${error.message}`,
    });
  }
}

module.exports = {
  SayHello,
  TestServer,
  GenerateFingerprint,
  GenerateUpdateFingerprint,
  Installation,
  GetAllFeature,
  GetRequestedFeature,
  ReleaseFeature,
};
