class Feature {
    constructor(featureId, featureName, enable, businessModel, startDate, issuedCount, consumedCount, availableCount, endDate, noOfDays) {
        this.featureId = featureId;
        this.featureName = featureName;
        this.enable = enable;
        this.businessModel = businessModel;
        this.startDate = startDate;
        this.issuedCount = issuedCount;
        this.consumedCount = consumedCount;
        this.availableCount = availableCount;
        this.endDate = endDate;
        this.noOfDays = noOfDays;
    }
}

module.exports = Feature;
