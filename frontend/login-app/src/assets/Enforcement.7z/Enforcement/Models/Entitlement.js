class Entitlement {
    constructor(entitlementId, timestamp, products = []) {
        this.entitlementId = entitlementId;
        this.timestamp = timestamp;
        this.products = products;
    }
}

module.exports = Entitlement;
