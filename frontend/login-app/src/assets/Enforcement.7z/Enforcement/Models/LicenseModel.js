class LicenseModel {
    constructor(id, userId,version, transfered,license) {
        this.id = id;
        this.userId = userId
        this.version = version;
        this.transfered = transfered;
        this.license = license;
    }
}

module.exports = LicenseModel;
