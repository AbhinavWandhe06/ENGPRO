const Feature = require('./Feature');

class Product {
    constructor(productId, productName, features = []) {
        this.productId = productId;
        this.productName = productName;
        this.features = features;
    }
}

module.exports = Product;
