const Feature = require('./Feature');

class Session {
    constructor(sessionId, featureID, userId, licenseId, timestamp) {
        this.sessionId = sessionId;
        this.featureID = featureID;
        this.userId = userId;
        this.licenseId = licenseId;
        this.timestamp = timestamp;
    }
}

module.exports = Session;
